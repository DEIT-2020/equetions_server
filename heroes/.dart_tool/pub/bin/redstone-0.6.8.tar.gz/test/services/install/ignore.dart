library ignore;

import 'package:redstone/redstone.dart';

@Route("/ignore")
String route() => "target_executed";

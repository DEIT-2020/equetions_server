#!/usr/bin/env bash
set -e
dart test/server_tests.dart
